# dameliya.exam
проект по анализу данных
